/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 100.0, "KoPercent": 0.0};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.3, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.0, 500, 1500, "A05-提交更新资料(自我介绍=狂神)"], "isController": false}, {"data": [0.5, 500, 1500, "B02-登录(admin/123456)"], "isController": false}, {"data": [0.0, 500, 1500, "B08-打开问题详情"], "isController": false}, {"data": [1.0, 500, 1500, "C01-打开登录页"], "isController": false}, {"data": [0.5, 500, 1500, "A02-登录(admin/123456)"], "isController": false}, {"data": [0.0, 500, 1500, "事务A2-更新资料"], "isController": true}, {"data": [0.0, 500, 1500, "B09-提交评论"], "isController": false}, {"data": [1.0, 500, 1500, "B01-打开登录页"], "isController": false}, {"data": [0.5, 500, 1500, "C02-登录(admin/123456)"], "isController": false}, {"data": [0.5, 500, 1500, "事务A1-登录"], "isController": true}, {"data": [0.0, 500, 1500, "C07-发布文章2"], "isController": false}, {"data": [0.0, 500, 1500, "B04-点击问答进入问答列表"], "isController": false}, {"data": [0.5, 500, 1500, "事务B1-登录"], "isController": true}, {"data": [1.0, 500, 1500, "A03-登录后首页"], "isController": false}, {"data": [0.0, 500, 1500, "B06-查询问题管理-第2页10条"], "isController": false}, {"data": [0.0, 500, 1500, "B10-验证评论已提交"], "isController": false}, {"data": [0.0, 500, 1500, "B05-查询问题管理-第1页10条"], "isController": false}, {"data": [0.0, 500, 1500, "事务C2-写文章并发布2篇"], "isController": true}, {"data": [1.0, 500, 1500, "C03-登录后首页"], "isController": false}, {"data": [0.0, 500, 1500, "A06-验证自我介绍已保存"], "isController": false}, {"data": [0.0, 500, 1500, "C06-发布文章1"], "isController": false}, {"data": [0.5, 500, 1500, "事务C1-登录"], "isController": true}, {"data": [0.0, 500, 1500, "事务B2-提交评论"], "isController": true}, {"data": [0.0, 500, 1500, "A04-点击头像打开更新资料页"], "isController": false}, {"data": [1.0, 500, 1500, "B03-登录后首页"], "isController": false}, {"data": [0.0, 500, 1500, "C04-点击博客进入博客列表"], "isController": false}, {"data": [0.0, 500, 1500, "C05-点击写文章打开编辑页"], "isController": false}, {"data": [1.0, 500, 1500, "A01-打开登录页"], "isController": false}, {"data": [0.0, 500, 1500, "C08-验证文章已发布"], "isController": false}, {"data": [0.0, 500, 1500, "B07-我的AI提问列表"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 48, 0, 0.0, 5690.354166666668, 5, 20875, 4830.5, 12210.800000000001, 17149.499999999978, 20875.0, 0.3748096669659938, 3.2921209444422757, 0.17657659196501777], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["A05-提交更新资料(自我介绍=狂神)", 2, 0, 0.0, 5435.5, 4773, 6098, 5435.5, 6098.0, 6098.0, 6098.0, 0.06143638262579099, 0.02057878832094366, 0.05081700789457516], "isController": false}, {"data": ["B02-登录(admin/123456)", 2, 0, 0.0, 2526.0, 253, 4799, 2526.0, 4799.0, 4799.0, 4799.0, 0.02422011238132145, 0.008538535712555707, 0.011790748068446039], "isController": false}, {"data": ["B08-打开问题详情", 2, 0, 0.0, 8463.0, 4775, 12151, 8463.0, 12151.0, 12151.0, 12151.0, 0.029475483766377313, 0.430733534257881, 0.011974415280090786], "isController": false}, {"data": ["C01-打开登录页", 2, 0, 0.0, 17.0, 6, 28, 17.0, 28.0, 28.0, 28.0, 0.03655237955990935, 0.05525691753783171, 0.013011076513268514], "isController": false}, {"data": ["A02-登录(admin/123456)", 2, 0, 0.0, 2635.5, 253, 5018, 2635.5, 5018.0, 5018.0, 5018.0, 0.08026326350429408, 0.028295935668994302, 0.03907347349305723], "isController": false}, {"data": ["事务A2-更新资料", 2, 0, 0.0, 22215.0, 19625, 24805, 22215.0, 24805.0, 24805.0, 24805.0, 0.04043017708417563, 0.8313060336985525, 0.06652817225276947], "isController": true}, {"data": ["B09-提交评论", 2, 0, 0.0, 4840.5, 4342, 5339, 4840.5, 5339.0, 5339.0, 5339.0, 0.03330890680167877, 0.011449936713077077, 0.02358296624142296], "isController": false}, {"data": ["B01-打开登录页", 2, 0, 0.0, 19.5, 11, 28, 19.5, 28.0, 28.0, 28.0, 0.025705288863183597, 0.03885916714864083, 0.00914997831116252], "isController": false}, {"data": ["C02-登录(admin/123456)", 2, 0, 0.0, 2276.0, 254, 4298, 2276.0, 4298.0, 4298.0, 4298.0, 0.03390692548953123, 0.011953515724336696, 0.01650644761380012], "isController": false}, {"data": ["事务A1-登录", 2, 0, 0.0, 2662.0, 291, 5033, 2662.0, 5033.0, 5033.0, 5033.0, 0.07992966189753017, 0.6239040894013269, 0.09663371233314684], "isController": true}, {"data": ["C07-发布文章2", 2, 0, 0.0, 6967.0, 4705, 9229, 6967.0, 9229.0, 9229.0, 9229.0, 0.03468488779438799, 0.010500307828379175, 0.03194125897471472], "isController": false}, {"data": ["B04-点击问答进入问答列表", 2, 0, 0.0, 12428.0, 12107, 12749, 12428.0, 12749.0, 12749.0, 12749.0, 0.02103646671505054, 0.41454576351855943, 0.007765414470985454], "isController": false}, {"data": ["事务B1-登录", 2, 0, 0.0, 2557.0, 291, 4823, 2557.0, 4823.0, 4823.0, 4823.0, 0.024188769154481572, 0.18880940610524533, 0.029243843958250183], "isController": true}, {"data": ["A03-登录后首页", 2, 0, 0.0, 10.0, 10, 10, 10.0, 10.0, 10.0, 10.0, 0.08106026830948809, 0.4816119847606696, 0.029685156851619182], "isController": false}, {"data": ["B06-查询问题管理-第2页10条", 2, 0, 0.0, 6501.5, 4039, 8964, 6501.5, 8964.0, 8964.0, 8964.0, 0.02387461054541548, 0.4704743810507216, 0.008929663905170047], "isController": false}, {"data": ["B10-验证评论已提交", 2, 0, 0.0, 8314.5, 6099, 10530, 8314.5, 10530.0, 10530.0, 10530.0, 0.03289203190527095, 0.4989053120631527, 0.013362387961516323], "isController": false}, {"data": ["B05-查询问题管理-第1页10条", 2, 0, 0.0, 5900.5, 4286, 7515, 5900.5, 7515.0, 7515.0, 7515.0, 0.022922898829786015, 0.451719897935793, 0.008573701417781293], "isController": false}, {"data": ["事务C2-写文章并发布2篇", 2, 0, 0.0, 18441.0, 15230, 21652, 18441.0, 21652.0, 21652.0, 21652.0, 0.02853677677106371, 0.24615756759649, 0.06314876578440466], "isController": true}, {"data": ["C03-登录后首页", 2, 0, 0.0, 11.0, 10, 12, 11.0, 12.0, 12.0, 12.0, 0.034047189404514656, 0.20228818392291717, 0.01246845315106738], "isController": false}, {"data": ["A06-验证自我介绍已保存", 2, 0, 0.0, 9225.0, 7532, 10918, 9225.0, 10918.0, 10918.0, 10918.0, 0.05351027397260274, 0.5411644504494864, 0.021895317182148974], "isController": false}, {"data": ["C06-发布文章1", 2, 0, 0.0, 7134.0, 4862, 9406, 7134.0, 9406.0, 9406.0, 9406.0, 0.03207132663042607, 0.009709093022882892, 0.029534434582511506], "isController": false}, {"data": ["事务C1-登录", 2, 0, 0.0, 2304.0, 292, 4316, 2304.0, 4316.0, 4316.0, 4316.0, 0.03384724737260742, 0.26420024243090934, 0.040920793210242175], "isController": true}, {"data": ["事务B2-提交评论", 2, 0, 0.0, 21618.0, 15216, 28020, 21618.0, 28020.0, 28020.0, 28020.0, 0.025544415352193626, 0.769525512484833, 0.03884048310875535], "isController": true}, {"data": ["A04-点击头像打开更新资料页", 2, 0, 0.0, 7554.5, 5995, 9114, 7554.5, 9114.0, 9114.0, 9114.0, 0.05921188974746129, 0.5988264943600675, 0.024228302543150664], "isController": false}, {"data": ["B03-登录后首页", 2, 0, 0.0, 11.5, 10, 13, 11.5, 13.0, 13.0, 13.0, 0.02429100625493411, 0.14432273638185464, 0.008895632173437786], "isController": false}, {"data": ["C04-点击博客进入博客列表", 2, 0, 0.0, 10168.5, 8231, 12106, 10168.5, 12106.0, 12106.0, 12106.0, 0.029867240117676927, 0.5762568974657647, 0.01090854277735466], "isController": false}, {"data": ["C05-点击写文章打开编辑页", 2, 0, 0.0, 4340.0, 3017, 5663, 4340.0, 5663.0, 5663.0, 5663.0, 0.03304856486607069, 0.265066272700233, 0.01226411586826842], "isController": false}, {"data": ["A01-打开登录页", 2, 0, 0.0, 16.5, 5, 28, 16.5, 28.0, 28.0, 28.0, 0.10035626473982638, 0.15171044708715942, 0.035722518064127656], "isController": false}, {"data": ["C08-验证文章已发布", 2, 0, 0.0, 16761.0, 12876, 20646, 16761.0, 20646.0, 20646.0, 20646.0, 0.032621637932440585, 0.8086916786279339, 0.013284397478347388], "isController": false}, {"data": ["B07-我的AI提问列表", 2, 0, 0.0, 15012.0, 9149, 20875, 15012.0, 20875.0, 20875.0, 20875.0, 0.023822002001048167, 0.5924792450807566, 0.009794006682071562], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": []}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 48, 0, "", "", "", "", "", "", "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
